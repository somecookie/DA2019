import java.io.IOException;

import ch.epfl.da.Main;

/**
 * 
 * Main class that only exist to satisfy project requirement.
 *
 */
public class Da_proc {

	public static void main(String[] args) throws IOException {
		Main.main(args);
	}
}

package ch.epfl.da.perfectLink;

public enum MessageType {
	MESSAGE, ACK
}
